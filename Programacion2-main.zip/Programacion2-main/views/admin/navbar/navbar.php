<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #212121;color:#ff7043;">
  <a class="navbar-brand" href="#" style="color:#ff7043;">SGMB</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php" style="color:#ff7043;">Inicio <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <!--form action="#" method="POST">
          <button class="btn nav-link" name="vista_inventario" href="#">Inventario</button>
        </form -->
        <a href="" class="btn nav-item inventario" style="color:#ff7043;">Inventario</a>
      </li>
      <li class="nav-item">
        <!-- form action="#" method="POST">
          <button class="btn nav-link" name="vista_usuario" href="#">Usuario</button>
        </form -->
        <a href="" class="btn nav-item usuario" style="color:#ff7043;">Usuario</a>
      </li>
      <li class="nav-item">
        <a class="btn nav-item ventas" href="#" style="color:#ff7043;">Ventas</a>
      </li>
    </ul>
    <span class="navbar-text">
      <a class="btn btn-danger" href="../../index.php" style="color:#ffffff;">Salir</a>
    </span>
  </div>
</nav>
